package com.example.wake.ethiocinemamovie.Models;



class afaf {
    private static final afaf ourInstance = new afaf();

    static afaf getInstance() {
        return ourInstance;
    }

    private afaf() {
    }
}
